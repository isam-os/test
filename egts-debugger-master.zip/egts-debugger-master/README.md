# egts-debugger

Scripts for debugging EGTS connection. For more information please look at documentation in doc directory.
